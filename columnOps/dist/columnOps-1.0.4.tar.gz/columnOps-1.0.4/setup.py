from distutils.core import setup

setup(
name = "columnOps",
version = '1.0.4',
py_modules = ['columnOps'],
author = 'Tirtharaj',
author_email = 'ananda.utsab@gmail.com',
url = 'traz.tumblr.com',
description = 'A function to display count of unique values, null values and operation (drop/impute) to be performed on a column',
)